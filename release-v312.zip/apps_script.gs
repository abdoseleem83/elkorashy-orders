// ==== طلبات الموزعين - القرشي — الباك إند (Google Apps Script) ====
//
// ⚠️⚠️ الملف ده نسخة مرجعية موجودة في مستودع **عام** على GitHub.
// ممنوع منعًا باتًا كتابة أي سر جواه (أرقام PIN، مفاتيح API، مفاتيح خاصة).
// كل الأسرار بتتخزّن في Script Properties — شوف setupWizard() تحت.
//
// خطوات النشر بعد أي تعديل:
//   ١) الصق الملف كله في محرر Apps Script
//   ٢) Deploy → Manage deployments → عدّل النشر الحالي → Version: New version
//   ٣) افتح /exec?action=version وتأكد إن الرقم الراجع = APP_VERSION تحت
//
// أول مرة بس: شغّل setupWizard() ثم installTriggers() من محرر Apps Script.

const APP_VERSION = 'v312-groups-session-zoom';

const SHEET_NAME = 'Orders';
const CATALOG_SHEET_NAME = 'الأصناف';
const DISCOUNT_SHEET_NAME = 'الخصومات';
const USERS_SHEET_NAME = 'المستخدمين';
const PW_REQUESTS_SHEET_NAME = 'طلبات الباسورد';
const ORDER_COUNTER_SHEET_NAME = 'عداد الطلبات';
const ERRORS_SHEET_NAME = 'أخطاء';

// ===== مراحل الطلب (لازم تطابق نفس النصوص في index.html بالظبط) =====
const STATUS_RECEIVED = 'تم استلام الطلب';
const STATUS_PENDING = STATUS_RECEIVED;   // اسم قديم — سايبينه عشان أي كود بيناديه
const STATUS_PREPARING = 'جاري تجهيز الطلب';   // مرحلة وسيطة — بتفضل محجوزة زي RECEIVED
const STATUS_DONE = 'تم تنفيذ الطلب';
const STATUS_EDITED = 'مُعدّل';            // حالة قديمة — بتفضل موجودة بس لطلبات اتعدّلت قبل v216
                                           // (شوف saveOrder_: من v216 الطلب القديم بيتمسح تمامًا
                                           // بدل ما يتعلّم "مُعدّل"، والطلب الجديد بيحمل علامة
                                           // EDIT_MARK_PREFIX_ في الملاحظات بدل كده)
// علامة مخفية بتتحط في أول عمود "ملاحظات" للطلب الجديد الناتج عن تعديل —
// بتتشال قبل ما تتعرض للموزع/الأدمن (شوف rowToOrder). مفيش داعي لعمود شيت
// جديد عشان كده، والصيغة دي آمنة (نص عادي مايتفلترش أو يتفسّر كأي حاجة تانية).
const EDIT_MARK_PREFIX_ = '⟦EDITED_FROM:';
const EDIT_MARK_SUFFIX_ = '⟧';

// أعمدة شيت Orders (1-indexed) — مكان واحد بدل أرقام سايبة في الكود
const COL_ID = 1, COL_TS = 2, COL_NAME = 3, COL_REGION = 4, COL_PHONE = 5,
      COL_NOTE = 6, COL_SUMMARY = 7, COL_STATUS = 8, COL_ITEMS = 9,
      COL_WAREHOUSE = 10, COL_ORDERNO = 11, COL_USERNAME = 12,
      COL_DONE_AT = 13;          // وقت ما اتحوّل «تم تنفيذ الطلب» (للحذف التلقائي بعد ٥ دقايق)
const ORDERS_HEADERS = ['رقم الطلب', 'التاريخ', 'الموزع', 'المنطقة', 'الهاتف', 'ملاحظات',
                        'ملخص الأصناف', 'الحالة', 'الأصناف (JSON)', 'المخزن',
                        'رقم الطلب بالمخزن', 'اسم المستخدم', 'وقت التنفيذ'];

// سطر الاعتماد في رسائل الواتساب — خليه '' لو عايز تشيله
const CREDIT_LINE = '🤲 ادعُ لصاحب هذا العمل بظهر الغيب';

// المخزن الوحيد اللي الرصيد بيتحجز عليه (الرصيد في شيت الأصناف رقم عام واحد)
// ⚠️🛘 CRITICAL: هذا الثابت يحدد المخزن الوحيد اللي بيتم حجز البضاعة له.
// ⚠️ تغيير قيمته = حجز بضاعة خاطئ + أرقام رصيد كاذبة لمخازن تانية.
// ⚠️ **بلاش تغيّره إلا لو قالتلك الإدارة العليا بالظبط.**
const RESERVED_WAREHOUSE_ = 'طنطا';

// مدة صلاحية التوكنات
const TTL_ADMIN_MS = 12 * 60 * 60 * 1000;        // ١٢ ساعة
const TTL_USER_MS  = 180 * 24 * 60 * 60 * 1000;  // ١٨٠ يوم (متوافق مع «افضل مسجّل دخول» في التطبيق)

// حد محاولات تسجيل الدخول الفاشلة قبل القفل المؤقت
const LOGIN_MAX_FAILS = 5;
const LOGIN_LOCK_SECONDS = 15 * 60;   // ١٥ دقيقة

// حد إجمالي لطلبات "تسجيل حساب جديد" في نفس النافذة الزمنية — بدون ده أي حد
// يقدر يغرق شيت "المستخدمين" وإشعارات الأدمن بحسابات وهمية.
const REGISTER_MAX_PER_WINDOW = 20;
const REGISTER_WINDOW_SECONDS = 15 * 60;   // ١٥ دقيقة


// ═══════════════════════════════════════════════════════════════════
//  الأسرار — كلها من Script Properties، مفيش ولا واحد مكتوب في الملف ده
// ═══════════════════════════════════════════════════════════════════

function props_() { return PropertiesService.getScriptProperties(); }

function secret_(key) {
  const v = props_().getProperty(key);
  return (v === null || v === undefined) ? '' : String(v);
}

/**
 * 🔧 شغّلها مرة واحدة من محرر Apps Script (المحرر ده خاص بيك، مش عام).
 *
 * الطريقة:
 *   ١) اكتب القيم جوه الأقواس تحت
 *   ٢) اضغط Run
 *   ٣) **امسح القيم تاني وسيبها فاضية واحفظ** — عشان لو الملف اتنسخ
 *      للمستودع العام مايبقاش فيه أي سر
 *
 * أي خانة بتسيبها فاضية مش هتتغيّر — يعني تقدر تشغّلها تاني لتغيير
 * رقم واحد بس من غير ما تكتب الباقي.
 */
function setupWizard() {
  const values = {
    ADMIN_PIN:        '',   // رقم فتح "متابعة المخزن"
    MANAGE_PIN:       ''    // رقم فتح تبويب "الإدارة"
  };

  const p = props_();
  const changed = [];
  Object.keys(values).forEach(function (k) {
    if (String(values[k]).trim()) { p.setProperty(k, String(values[k]).trim()); changed.push(k); }
  });
  ensureTokenSecret_();

  const missing = ['ADMIN_PIN', 'MANAGE_PIN']
    .filter(function (k) { return !secret_(k); });

  const msg = 'اتغيّر: ' + (changed.length ? changed.join('، ') : 'لا شيء') +
              '\nلسه ناقص: ' + (missing.length ? missing.join('، ') : 'لا شيء ✅');
  Logger.log(msg);
  return msg;
}

/** بيتأكد إن فيه مفتاح توقيع للتوكنات، وبينشئه لو مش موجود. */
function ensureTokenSecret_() {
  const p = props_();
  let s = p.getProperty('TOKEN_SECRET');
  if (!s) {
    s = Utilities.getUuid() + Utilities.getUuid();
    p.setProperty('TOKEN_SECRET', s);
  }
  return s;
}

/**
 * 🚨 بيلغي كل التوكنات الصالحة فورًا (أدمن + إدارة + كل الموزعين).
 * شغّلها لو شكيت إن حد وصل لتوكن، أو بعد ما تغيّر أرقام الـ PIN.
 */
function revokeAllTokens() {
  props_().setProperty('TOKEN_SECRET', Utilities.getUuid() + Utilities.getUuid());
  return 'كل التوكنات اتلغت — كل الناس هتحتاج تدخل تاني.';
}


// ═══════════════════════════════════════════════════════════════════
//  التوكنات — موقّعة بـ HMAC، مش متخزنة
// ═══════════════════════════════════════════════════════════════════
//
// قبل كده كان كل توكن بيتخزّن كـ property مستقل ومابيتمسحش أبدًا، فـ Script
// Properties كان بيكبر للأبد لحد ما يوصل للحد (500KB) ويقع كل حاجة.
// دلوقتي التوكن نفسه بيحمل بياناته وتوقيعه: role|subject|expiry + HMAC-SHA256.
// السيرفر بيتحقق من التوقيع من غير ما يخزّن حاجة — صفر تخزين وصفر تنضيف.

function b64uEncode_(str) {
  return Utilities.base64EncodeWebSafe(str, Utilities.Charset.UTF_8).replace(/=+$/, '');
}
function b64uDecode_(s) {
  const pad = s.length % 4;
  if (pad) s += '===='.slice(pad);
  return Utilities.newBlob(Utilities.base64DecodeWebSafe(s)).getDataAsString();
}
function hmacB64u_(payload) {
  const sig = Utilities.computeHmacSha256Signature(payload, ensureTokenSecret_());
  return Utilities.base64EncodeWebSafe(sig).replace(/=+$/, '');
}

/** role: 'admin' | 'manage' | 'user' — subject: اسم المستخدم (أو '' للأدمن) */
function userAuthRevisionKey_(username) {
  // Hash the normalized name to keep Script Property keys short and unambiguous.
  return 'USER_AUTH_REV_' + hmacB64u_('revision-key:' + String(username || '').trim().toLowerCase());
}
function userAuthRevision_(username) {
  return props_().getProperty(userAuthRevisionKey_(username)) || '';
}
function revokeUserTokens_(username) {
  props_().setProperty(userAuthRevisionKey_(username), Utilities.getUuid());
}
function userCredentialStamp_(username, storedPassword) {
  // Keyed fingerprint only. Never expose the stored password/hash in the token.
  return hmacB64u_(JSON.stringify(['user-session-v2', String(username || '').trim().toLowerCase(),
    String(storedPassword || ''), userAuthRevision_(username)]));
}
function signToken_(role, subject, ttlMs, storedPassword) {
  const expiry = Date.now() + ttlMs;
  let payload;
  if (role === 'user') {
    if (!String(storedPassword || '')) throw new Error('Missing session credential');
    payload = 'user2|' + b64uEncode_(JSON.stringify({
      u: String(subject || ''), e: expiry, p: userCredentialStamp_(subject, storedPassword)
    }));
  } else {
    payload = role + '|' + String(subject || '') + '|' + expiry;
  }
  return b64uEncode_(payload) + '.' + hmacB64u_(payload);
}

/** Return the subject only after signature, expiry and current account checks. */
function verifyToken_(token, wantRole) {
  try {
    const t = String(token || '');
    const dot = t.indexOf('.');
    if (dot < 1) return null;
    const payload = b64uDecode_(t.slice(0, dot));
    if (hmacB64u_(payload) !== t.slice(dot + 1)) return null;
    if (wantRole === 'user') {
      // Old user tokens have no password binding. A one-time password login is
      // required on migration. Admin/manage tokens retain their existing format.
      if (payload.indexOf('user2|') !== 0) return null;
      const session = JSON.parse(b64uDecode_(payload.slice(6)));
      if (typeof session.u !== 'string' || !session.u ||
          typeof session.e !== 'number' || !Number.isFinite(session.e) || Date.now() >= session.e ||
          typeof session.p !== 'string' || !session.p) return null;
      // Do not cache: password/status changes must apply to the next request.
      const rows = getUsersSheet_().getDataRange().getValues();
      for (let i = 1; i < rows.length; i++) {
        if (String(rows[i][0]).trim().toLowerCase() !== session.u.trim().toLowerCase()) continue;
        if (String(rows[i][5] || '').trim() !== 'مفعل' || !String(rows[i][1] || '')) return null;
        return session.p === userCredentialStamp_(session.u, rows[i][1]) ? String(rows[i][0]).trim() : null;
      }
      return null;
    }
    const first = payload.indexOf('|');
    const last = payload.lastIndexOf('|');
    if (first < 0 || last <= first) return null;
    const role = payload.slice(0, first);
    const subject = payload.slice(first + 1, last);
    const expiry = Number(payload.slice(last + 1));
    if (role !== wantRole || !Number.isFinite(expiry) || Date.now() >= expiry) return null;
    return subject;
  } catch (e) { return null; }
}

function isValidAdminToken_(token) {
  return verifyToken_(token, 'admin') !== null;
}
// الأدمن ليه نفس صلاحية الإدارة أو أعلى، فتوكنه مقبول في نداءات الإدارة كمان.
function isValidManageToken_(token) {
  return verifyToken_(token, 'manage') !== null || isValidAdminToken_(token);
}
/** بيرجّع اسم المستخدم لو التوكن توكن موزّع صالح، أو null. */
function userFromToken_(token) {
  const u = verifyToken_(token, 'user');
  return u ? u : null;
}

// 🔒 نفس آلية قفل محاولات الدخول (isLoginLocked_) لكن بمفتاح ثابت بدل اسم
// مستخدم — عشان محدش يقدر يجرّب رقم الـ PIN آلاف المرات في السكريبت.
function adminLogin_(pin) {
  const real = secret_('ADMIN_PIN');
  if (!real) return { ok: false, reason: 'not_configured' };
  if (isLoginLocked_('admin_pin')) return { ok: false, reason: 'locked' };
  if (String(pin || '').trim() !== real) { noteLoginFail_('admin_pin'); return { ok: false, reason: 'wrong_pin' }; }
  clearLoginFails_('admin_pin');
  return { ok: true, token: signToken_('admin', '', TTL_ADMIN_MS) };
}

function manageLogin_(pin) {
  const real = secret_('MANAGE_PIN');
  if (!real) return { ok: false, reason: 'not_configured' };
  if (isLoginLocked_('manage_pin')) return { ok: false, reason: 'locked' };
  if (String(pin || '').trim() !== real) { noteLoginFail_('manage_pin'); return { ok: false, reason: 'wrong_pin' }; }
  clearLoginFails_('manage_pin');
  return { ok: true, token: signToken_('manage', '', TTL_ADMIN_MS) };
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
// 🔒 حقن الصيغ (Formula Injection): أي نص بيبدأ بـ = أو + أو - أو @ وبيتكتب في الشيت
// بـ appendRow/setValues بيتفسّر كصيغة. تسجيل الحساب مفتوح من غير توكن، فأي حد كان
// يقدر يكتب في «اسم الموزع» صيغة زي =IMPORTXML(...) تقرا شيت المستخدمين وتبعته لموقعه.
// بنحط حرف غير مرئي (U+200E) في أول النص عشان مايتفسّرش صيغة أبدًا — حتى لو اتنقل
// لشيت تاني (أرشيف/استرجاع). مابنلمسش الحقول اللي بتتقارن (اسم المستخدم) — دي بتترفض.
function cellSafe_(v) {
  const t = String(v == null ? '' : v);
  return /^[\s\u200E]*[=+\-@]/.test(t) ? '\u200E' + t : t;
}
// اسم المستخدم بيتقارن حرفيًا في الدخول، فمينفعش نعدّله — بنرفض اللي بيبدأ بحرف صيغة.
function isBadUsername_(u) {
  return /^[=+\-@\t\r]/.test(u) || u.length > 60;
}
// بيشيل أي سر من جسم الطلب قبل ما يتسجّل في شيت الأخطاء
function redactBody_(raw) {
  try {
    const o = JSON.parse(raw);
    ['password', 'newPassword', 'token', 'pin'].forEach(function (k) { if (k in o) o[k] = '***'; });
    return JSON.stringify(o);
  } catch (e) { return '(جسم غير قابل للقراءة)'; }
}
function denyAdmin_()  { return json_({ ok: false, error: 'unauthorized' }); }
function denyManage_() { return json_({ ok: false, error: 'unauthorized' }); }
function denyAuth_()   { return json_({ ok: false, error: 'unauthorized' }); }


// ═══════════════════════════════════════════════════════════════════
//  كلمات المرور — SHA-256 مع salt لكل مستخدم
// ═══════════════════════════════════════════════════════════════════
//
// الحسابات القديمة باسووردها متخزّن نص صريح. مابنكسرهاش: أول ما المستخدم
// يدخل بنجاح بالباسورد القديم، بنحوّله لـ hash في نفس اللحظة (ترقية صامتة).
// بعد فترة كل الحسابات هتبقى مشفّرة من غير ما حد يعمل حاجة.

function hashPw_(pw, salt) {
  const raw = Utilities.computeDigest(
    Utilities.DigestAlgorithm.SHA_256, salt + '|' + String(pw), Utilities.Charset.UTF_8);
  return raw.map(function (b) { return ((b & 0xFF) + 0x100).toString(16).slice(1); }).join('');
}
function makePwHash_(pw) {
  const salt = Utilities.getUuid().replace(/-/g, '').slice(0, 16);
  return 'sha256$' + salt + '$' + hashPw_(pw, salt);
}
function isHashedPw_(stored) {
  return String(stored || '').indexOf('sha256$') === 0;
}
function verifyPw_(stored, pw) {
  const s = String(stored || '');
  if (isHashedPw_(s)) {
    const parts = s.split('$');
    return parts.length === 3 && hashPw_(pw, parts[1]) === parts[2];
  }
  return s !== '' && s === String(pw);   // حساب قديم بنص صريح
}

/**
 * 🔧 اختياري: بيحوّل كل الباسوردات المتخزنة نص صريح لـ hash دفعة واحدة.
 * ⚠️ بعد ما تشغّلها، الباسوردات مش هتبقى مقروءة من الشيت خالص (وده المطلوب) —
 * لو نسي حد باسورده، الحل الوحيد يبقى "نسيت كلمة المرور" جوه التطبيق.
 */
function hashAllPasswords() {
  const sheet = getUsersSheet_();
  const n = sheet.getLastRow() - 1;
  if (n < 1) return 'مفيش مستخدمين.';
  const range = sheet.getRange(2, 2, n, 1);
  const vals = range.getValues();
  let done = 0;
  for (let i = 0; i < vals.length; i++) {
    const cur = String(vals[i][0] || '');
    if (cur && !isHashedPw_(cur)) { vals[i][0] = makePwHash_(cur); done++; }
  }
  if (done) range.setValues(vals);
  return 'اتشفّر ' + done + ' باسورد.';
}

// ===== حد محاولات الدخول =====
// بنستخدم CacheService لأنه بيمسح نفسه لوحده بعد المدة — مفيش تنضيف يدوي.
function loginFailKey_(username) {
  return 'lf_' + String(username || '').trim().toLowerCase();
}
function isLoginLocked_(username) {
  try {
    const n = Number(CacheService.getScriptCache().get(loginFailKey_(username)) || 0);
    return n >= LOGIN_MAX_FAILS;
  } catch (e) { return false; }
}
function noteLoginFail_(username) {
  try {
    const cache = CacheService.getScriptCache();
    const key = loginFailKey_(username);
    const n = Number(cache.get(key) || 0) + 1;
    cache.put(key, String(n), LOGIN_LOCK_SECONDS);
  } catch (e) {}
}
function clearLoginFails_(username) {
  try { CacheService.getScriptCache().remove(loginFailKey_(username)); } catch (e) {}
}

// ===== حد معدّل التسجيل =====
// عدّاد عام (مش لكل مستخدم — لسه مفيش اسم مستخدم وقت التسجيل) بيمنع إغراق
// النظام بحسابات وهمية. بيمسح نفسه لوحده بعد النافذة الزمنية.
function isRegisterFlooded_() {
  try {
    const n = Number(CacheService.getScriptCache().get('reg_flood') || 0);
    return n >= REGISTER_MAX_PER_WINDOW;
  } catch (e) { return false; }
}
function noteRegisterAttempt_() {
  try {
    const cache = CacheService.getScriptCache();
    const n = Number(cache.get('reg_flood') || 0) + 1;
    cache.put('reg_flood', String(n), REGISTER_WINDOW_SECONDS);
  } catch (e) {}
}


// ═══════════════════════════════════════════════════════════════════
//  تجهيز الشيتات
// ═══════════════════════════════════════════════════════════════════
//
// ⚠️ تحذير تاريخي: النسخة القديمة من setup() كانت فيها sheet.clear() —
// يعني أي Run عليها (حتى بالغلط، وهي أول دالة في القائمة!) كان بيمسح كل
// الطلبات. ده حصل فعلاً واتفقدت طلبات. دلوقتي الدالة "آمنة": بتعمل الشيتات
// لو مش موجودة وبتضيف العناوين لو الشيت فاضي — عمرها ما بتمسح أي بيانات.

function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) sheet = ss.insertSheet(SHEET_NAME);
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(ORDERS_HEADERS);
    sheet.setFrozenRows(1);
  } else {
    // شيت قديم — نضيف عناوين الأعمدة الجديدة بس، من غير ما نلمس أي بيانات
    if (!sheet.getRange(1, COL_ORDERNO).getValue()) sheet.getRange(1, COL_ORDERNO).setValue(ORDERS_HEADERS[COL_ORDERNO - 1]);
    if (!sheet.getRange(1, COL_USERNAME).getValue()) sheet.getRange(1, COL_USERNAME).setValue(ORDERS_HEADERS[COL_USERNAME - 1]);
    if (!sheet.getRange(1, COL_DONE_AT).getValue()) sheet.getRange(1, COL_DONE_AT).setValue(ORDERS_HEADERS[COL_DONE_AT - 1]);
  }
  getUsersSheet_();
  ensureTokenSecret_();
  return 'تمام — الشيتات جاهزة.';
}

/** 🔧 شغّلها مرة واحدة: بتركّب كل الـ triggers المطلوبة. */
// ⚠️ 'processWhatsAppQueue' فضلت في القايمة دي (من غير ما نعيد تركيبها تحت)
// قصدًا — عشان أول مرة تشغّل الدالة دي بعد إلغاء ميزة واتساب، أي trigger
// قديم شغال عليها (من نسخة قبل الإلغاء) يتمسح. شغّلها مرة واحدة بعد النشر.
// 'minuteSync_' بقت هي المسؤولة عن مزامنة الرصيد كل دقيقة بدل ما تكون
// مركوبة على trigger الواتساب القديم — عشان سرعة تحديث الرصيد (المحجوز)
// متتأثرش بإلغاء ميزة واتساب.
function installTriggers() {
  const wanted = { 'processWhatsAppQueue': 1, 'minuteSync_': 1, 'reconcileReserved': 10, 'purgeDoneOrdersTrigger_': 1 };
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (wanted.hasOwnProperty(t.getHandlerFunction())) ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('minuteSync_').timeBased().everyMinutes(1).create();
  ScriptApp.newTrigger('reconcileReserved').timeBased().everyMinutes(10).create();
  ScriptApp.newTrigger('purgeDoneOrdersTrigger_').timeBased().everyMinutes(1).create();
  return 'اتركّبت: مزامنة المحجوز (كل دقيقة + كل ١٠ دقايق شبكة أمان) + حذف المنفَّذ بعد ٥ دقايق (فحص كل دقيقة). أي trigger قديم لواتساب اتمسح.';
}

function getUsersSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(USERS_SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(USERS_SHEET_NAME);
    sheet.appendRow(['اسم المستخدم', 'كلمة المرور', 'اسم الموزع', 'المنطقة', 'الهاتف',
                     'الحالة', 'تاريخ التسجيل', 'النوع', '', 'مفتاح واتساب', 'اشتراك Push']);
    sheet.setFrozenRows(1);
  }
  return sheet;
}

function getPwRequestsSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(PW_REQUESTS_SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(PW_REQUESTS_SHEET_NAME);
    sheet.appendRow(['رقم الطلب', 'التاريخ', 'اسم المستخدم', 'الباسورد الجديد', 'الحالة']);
    sheet.setFrozenRows(1);
  }
  return sheet;
}

// 🐞 بق حقيقي (نمو غير محدود): زي شيت طابور الواتساب بالظبط — كان بيتضاف
// له صف مع كل خطأ للأبد من غير أي حد أقصى. ERRORS_MAX_ROWS_ بيحافظ على
// آخر عدد معقول بس (getLastRow بس، مش قراءة كامل الشيت، فالتكلفة زهيدة).
const ERRORS_MAX_ROWS_ = 1000;

function logError_(where, err, extra) {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let s = ss.getSheetByName(ERRORS_SHEET_NAME);
    if (!s) { s = ss.insertSheet(ERRORS_SHEET_NAME); s.appendRow(['التاريخ', 'الخطأ', 'البيانات']); s.setFrozenRows(1); }
    s.appendRow([new Date(), where + ': ' + String(err && err.stack ? err.stack : err), String(extra || '').slice(0, 400)]);
    const n = s.getLastRow() - 1;
    if (n > ERRORS_MAX_ROWS_) s.deleteRows(2, n - ERRORS_MAX_ROWS_);
  } catch (e2) {}
}


// ═══════════════════════════════════════════════════════════════════
//  doPost — كل العمليات اللي بتغيّر بيانات
// ═══════════════════════════════════════════════════════════════════
//
// ⚠️ كل عملية بتعدّل أو بتمسح بقت هنا (POST) مش في doGet. قبل كده كان
// ?action=delete مجرد رابط — أي حد يفتحه (أو أي أداة بتعمل prefetch للروابط)
// كان بيمسح طلب. GET المفروض يقرا بس.

function doPost(e) {
  try {
    return doPostInner_(e);
  } catch (err) {
    logError_('doPost', err, e && e.postData ? redactBody_(e.postData.contents) : '');
    return json_({ ok: false, error: String(err) });
  }
}

function doPostInner_(e) {
  const data = JSON.parse(e.postData.contents);
  const action = String(data.action || '');
  const token = data.token;

  // ---------- عمليات مفتوحة (بدون توكن) ----------
  if (action === 'login')                 return json_(handleLogin(data.username || '', data.password || ''));
  if (action === 'register')              return handleRegister(data);
  if (action === 'requestPasswordReset')  return handleRequestPasswordReset(data);

  // ---------- عمليات الموزّع (بتوكن المستخدم) ----------
  if (action === 'savePushSub') {
    // 🔒 قبل كده أي حد كان يقدر يبعت اسم أي مستخدم ويمسح/يغيّر اشتراكه.
    const me = userFromToken_(token);
    if (!me) return denyAuth_();
    return json_({ ok: savePushSub_(me, data.sub || null) });
  }

  // ---------- إدارة الأصناف ----------
  if (action === 'manageUpdateCatalogItem') {
    if (!isValidManageToken_(token)) return denyManage_();
    return json_({ ok: updateCatalogItem_(data.item || {}) });
  }
  if (action === 'manageCreateAccGroup') {
    if (!isValidManageToken_(token)) return denyManage_();
    return json_(createAccCustomGroup_(data));
  }
  if (action === 'manageSetAccDisplayGroup') {
    if (!isValidManageToken_(token)) return denyManage_();
    return json_(setAccDisplayGroup_(data));
  }
  if (action === 'manageSetProductType') {
    if (!isValidManageToken_(token)) return denyManage_();
    return json_({ ok: setProductType_(data.main, data.product, data.type) });
  }
  if (action === 'manageAddCatalogItem') {
    if (!isValidManageToken_(token)) return denyManage_();
    return json_({ ok: addCatalogItem_(data.item || {}) });
  }
  if (action === 'manageClearAllStock') {
    if (!isValidManageToken_(token)) return denyManage_();
    return json_(Object.assign({ ok: true }, clearAllCatalogColumn_(8)));   // H=الرصيد
  }
  if (action === 'manageClearAllPrices') {
    if (!isValidManageToken_(token)) return denyManage_();
    return json_(Object.assign({ ok: true }, clearAllCatalogColumn_(7)));   // G=السعر
  }
  if (action === 'manageClearPricesByGroups') {
    if (!isValidManageToken_(token)) return denyManage_();
    return json_(Object.assign({ ok: true }, clearCatalogPricesByGroups_(data.groups || [])));
  }
  if (action === 'uploadCatalog') {
    if (!isValidAdminToken_(token)) return denyAdmin_();
    return json_(Object.assign({ ok: true }, bulkUpdateCatalog_(data.rows || [], data.mode || 'full')));
  }
  if (action === 'manageUploadCatalog') {
    if (!isValidManageToken_(token)) return denyManage_();
    return json_(Object.assign({ ok: true }, bulkUpdateCatalog_(data.rows || [], data.mode || 'full')));
  }

  // ---------- موافقات الإدارة ----------
  if (action === 'manageApproveReg' || action === 'manageRejectReg') {
    if (!isValidManageToken_(token)) return denyManage_();
    return json_({ ok: decideRegRequest_(data.username, action === 'manageApproveReg') });
  }
  if (action === 'manageApprovePasswordReset' || action === 'manageRejectPasswordReset') {
    if (!isValidManageToken_(token)) return denyManage_();
    return json_({ ok: decidePwRequest_(data.id, action === 'manageApprovePasswordReset') });
  }
  if (action === 'approvePasswordReset' || action === 'rejectPasswordReset') {
    if (!isValidAdminToken_(token)) return denyAdmin_();
    return json_({ ok: decidePwRequest_(data.id, action === 'approvePasswordReset') });
  }

  // ---------- عمليات الأدمن على الطلبات ----------
  if (action === 'updateStatus') {
    if (!isValidAdminToken_(token)) return denyAdmin_();
    return json_(updateOrderStatus_(data.id, data.status));
  }
  if (action === 'delete') {
    if (!isValidAdminToken_(token)) return denyAdmin_();
    return json_(deleteOrderById_(data.id));
  }
  // 🔒 حذف الموزّع لطلبه هو بس (شاشة "طلباتي") — توكن موزّع عادي، مش أدمن.
  // الفحص الحقيقي (الطلب ده فعلاً بتاعه، ومش "منفَّذ" بالفعل) جوه deleteMyOrder_.
  if (action === 'deleteMyOrder') {
    if (!userFromToken_(token)) return denyAuth_();
    return json_(deleteMyOrder_(data.id, token));
  }
  if (action === 'deleteDelivered') {
    if (!isValidAdminToken_(token)) return denyAdmin_();
    return json_(deleteDeliveredOrders_());
  }

  // ---------- الأدمن يعدّل كميات طلب موزّع / يعمل طلب باسم موزّع ----------
  if (action === 'adminUpdateItems') {
    if (!isValidAdminToken_(token)) return denyAdmin_();
    return json_(adminUpdateOrderItems_(data.id, data.items));
  }
  if (action === 'adminCreate') {
    if (!isValidAdminToken_(token)) return denyAdmin_();
    // الطلب بيتنسب للموزّع المختار (اسم المستخدم بتاعه) كأنه هو اللي باعته
    const target = userInfo_(String(data.forUsername || ''));
    if (!target) return json_({ ok: false, error: 'الموزّع ده مش موجود' });
    const d = Object.assign({}, data, { action: 'create', status: STATUS_PENDING });
    return saveOrder_(d, target.username);
  }

  // ---------- حفظ / تعديل طلب ----------
  // 🔒 قبل كده كان بيقبل الحفظ من غير توكن خالص، ولو مفيش توكن كان بياخد
  // username من اللي الواجهة بعتته زي ما هو — يعني أي حد يعرف رابط الـ/exec
  // (المكتوب في index.html اللي في مستودع عام) يقدر يحقن طلب وهمي منسوب
  // لأي اسم موزّع حقيقي، من غير تسجيل دخول خالص. دلوقتي لازم توكن موزّع صالح.
  if (action === 'create' || action === 'update') {
    if (!userFromToken_(token)) return denyAuth_();
    return saveOrder_(data);
  }

  return json_({ ok: false, error: 'unknown action: ' + action });
}


// ═══════════════════════════════════════════════════════════════════
//  حفظ وتعديل الطلبات
// ═══════════════════════════════════════════════════════════════════

function saveOrder_(data, asUser) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  if (!sheet) return json_({ ok: false, error: 'sheet not found' });

  const items = mergeDuplicateItems_(Array.isArray(data.items) ? data.items : []);
  const itemsSummary = cellSafe_(items.map(function (it) {
    return it.product + (it.color ? ' - ' + it.color : '') + ' × ' + it.qty + ' ' + (it.unitType || '');
  }).join(' | '));

  const isUpdate = data.action === 'update';
  // اسم المستخدم بيتاخد من التوكن بس — مش من اللي الواجهة بعتته، عشان محدش
  // يقدر ينسب طلب لحساب مش بتاعه. doPostInner_ بيتأكد إن التوكن صالح قبل ما
  // يوصل هنا أصلاً، فمفيش داعي لأي fallback على data.username.
  // asUser بيتبعت من السيرفر بس (adminCreate) بعد ما الأدمن يتأكد — مش من الواجهة
  const username = asUser || userFromToken_(data.token) || '';

  const idCol = sheet.getLastRow() > 1
    ? sheet.getRange(2, COL_ID, sheet.getLastRow() - 1, 1).getValues()
    : [];

  // 🔒 idempotent: نفس رقم الطلب اتسجّل قبل كده (ضغطة مرتين أو إعادة محاولة
  // من النت) → مانضيفش صف تاني، بنرجّع رقم الطلب الموجود زي ما هو.
  for (let i = 0; i < idCol.length; i++) {
    if (String(idCol[i][0]) === String(data.id)) {
      const existingNo = sheet.getRange(i + 2, COL_ORDERNO).getValue();
      return json_({ ok: true, orderNo: existingNo || '', duplicate: true });
    }
  }

  // ✏️ التعديل بيعمل صف **جديد** برقم وتاريخ جديد، والقديم بيتمسح تمامًا —
  // يفضل الطلب الجديد بس، وعليه علامة "معدّل" (شوف EDIT_MARK_PREFIX_ ورجّع
  // على rowToOrder) بدل ما يفضل الصف القديم معلَّق بحالة "مُعدّل" للأبد.
  //
  // 🔒 ثغرة اتصلحت (لسه سارية): الكود القديم كان بيعلّم أي صف رقمه = oldId
  // من غير ما يتأكد إن الطلب ده بتاع نفس الموزّع اللي باعت. يعني أي موزّع
  // مسجّل دخول كان يقدر يبعت oldId بتاع طلب **موزّع تاني** ويمسحه. دلوقتي
  // بنتأكد من الملكية: إما اسم المستخدم مطابق، أو (للطلبات القديمة اللي
  // مالهاش عمود اسم مستخدم) رقم التليفون مطابق. غير كده بنسيب الصف القديم
  // زي ما هو من غير ما نمسحه.
  // 🔒 ماينفعش تعديل طلب بقى "جاري تجهيز" أو "منفَّذ" — المخزن ممكن يكون
  // بدأ يجهّزه بالفعل. الواجهة بتخفي زرار التعديل في الحالتين دول، وهنا
  // بنمنعها فعليًا حتى لو حد بعت الطلب مباشرة للسيرفر متخطّيًا الواجهة.
  let editedFromOrderNo = '';
  if (isUpdate && data.oldId != null && String(data.oldId)) {
    const oldId = String(data.oldId);
    const myPhone = normalizePhone((userInfo_(username) || {}).phone || '');
    for (let i = 0; i < idCol.length; i++) {
      if (String(idCol[i][0]) !== oldId) continue;
      const rowUser = String(sheet.getRange(i + 2, COL_USERNAME).getValue() || '').trim();
      const rowPhone = normalizePhone(sheet.getRange(i + 2, COL_PHONE).getValue());
      const mine = rowUser
        ? (rowUser.toLowerCase() === String(username).trim().toLowerCase())
        : (!!myPhone && rowPhone === myPhone);
      if (mine) {
        const oldStatus = String(sheet.getRange(i + 2, COL_STATUS).getValue() || '').trim();
        if (oldStatus === STATUS_PREPARING || oldStatus === STATUS_DONE) {
          return json_({ ok: false, error: 'الطلب ده بقى قيد التجهيز أو اتنفّذ — متقدرش تعدّله دلوقتي' });
        }
        editedFromOrderNo = String(sheet.getRange(i + 2, COL_ORDERNO).getValue() || '');
        sheet.deleteRow(i + 2);   // الصف القديم بيتمسح تمامًا — الجديد بس اللي فاضل
      }
      break;
    }
  }

  const orderNo = getNextOrderNumber_(data.warehouse);
  const newRow = sheet.getLastRow() + 1;
  sheet.getRange(newRow, COL_PHONE).setNumberFormat('@');
  const noteToSave = editedFromOrderNo
    ? (EDIT_MARK_PREFIX_ + editedFromOrderNo + EDIT_MARK_SUFFIX_ + cellSafe_(data.note))
    : cellSafe_(data.note);
  sheet.appendRow([
    cellSafe_(data.id), new Date(data.ts), cellSafe_(data.distName), cellSafe_(data.distRegion),
    String(data.distPhone || ''), noteToSave, itemsSummary,
    isUpdate ? STATUS_PENDING : (data.status || STATUS_PENDING),
    JSON.stringify(items), cellSafe_(data.warehouse), orderNo, username
  ]);

  markReservedDirty_();   // بيتزامن في الخلفية خلال دقيقة
  return json_({ ok: true, orderNo: orderNo });
}

// ✏️ الأدمن يعدّل أصناف/كميات طلب موجود (نفس الصف ونفس الرقم) — مش بيتعدّل لو اتنفّذ.
function adminUpdateOrderItems_(id, itemsIn) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  if (!sheet) return { ok: false, error: 'sheet not found' };
  const items = mergeDuplicateItems_(Array.isArray(itemsIn) ? itemsIn : []).filter(function (it) { return Number(it.qty) > 0; });
  if (!items.length) return { ok: false, error: 'الطلب لازم يفضل فيه صنف واحد على الأقل' };
  const n = sheet.getLastRow() - 1;
  if (n < 1) return { ok: false, error: 'not found' };
  const ids = sheet.getRange(2, COL_ID, n, 1).getValues();
  for (let i = 0; i < ids.length; i++) {
    if (String(ids[i][0]) !== String(id)) continue;
    const row = i + 2;
    const st = String(sheet.getRange(row, COL_STATUS).getValue() || '').trim();
    if (st === STATUS_DONE) return { ok: false, error: 'الطلب ده اتنفّذ — مينفعش يتعدّل' };
    const summary = cellSafe_(items.map(function (it) {
      return it.product + (it.color ? ' - ' + it.color : '') + ' × ' + it.qty + ' ' + (it.unitType || '');
    }).join(' | '));
    sheet.getRange(row, COL_SUMMARY).setValue(summary);
    sheet.getRange(row, COL_ITEMS).setValue(JSON.stringify(items));
    markReservedDirty_();
    return { ok: true, items: items };
  }
  return { ok: false, error: 'الطلب مش موجود' };
}

// 👥 قايمة الموزعين المعتمدين (للأدمن عشان يعمل طلب باسم موزّع)
function listDistributors_() {
  const rows = getUsersSheet_().getDataRange().getValues();
  const out = [];
  for (let i = 1; i < rows.length; i++) {
    const u = String(rows[i][0] || '').trim();
    if (!u) continue;
    const st = String(rows[i][5] || '').trim();
    if (st !== 'مفعل') continue;   // الحسابات المفعّلة بس (زي handleLogin)
    out.push({ username: u, distName: String(rows[i][2] || ''), region: String(rows[i][3] || ''), phone: normalizePhone(rows[i][4]) });
  }
  return out;
}

// رقم الطلب لكل مخزن بيبدأ من 1 ويزيد لوحده — كل مخزن ليه عدّاد مستقل.
// Lock عشان لو طلبين اتبعتوا في نفس اللحظة من نفس المخزن مايخدوش نفس الرقم.
function getNextOrderNumber_(warehouse) {
  const wh = String(warehouse || 'عام').trim() || 'عام';
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = ss.getSheetByName(ORDER_COUNTER_SHEET_NAME);
    if (!sheet) {
      sheet = ss.insertSheet(ORDER_COUNTER_SHEET_NAME);
      sheet.appendRow(['المخزن', 'آخر رقم']);
      sheet.setFrozenRows(1);
    }
    const rows = sheet.getDataRange().getValues();
    for (let i = 1; i < rows.length; i++) {
      if (String(rows[i][0]).trim() === wh) {
        const next = (Number(rows[i][1]) || 0) + 1;
        sheet.getRange(i + 1, 2).setValue(next);
        return next;
      }
    }
    sheet.appendRow([wh, 1]);
    return 1;
  } finally {
    lock.releaseLock();
  }
}

// نفس الصنف (القطاع + المنتج + اللون + الوحدة) مايتكررش في الطلب: بنجمع الكميات في سطر واحد.
function mergeDuplicateItems_(items) {
  const out = [], idx = {};
  items.forEach(function (it) {
    if (!it || typeof it !== 'object') return;
    const key = [it.main, it.product, it.name, it.color, it.unitType].map(function (x) { return String(x == null ? '' : x).trim(); }).join('|');
    if (Object.prototype.hasOwnProperty.call(idx, key)) {
      const t = out[idx[key]];
      t.qty = Math.round(((Number(t.qty) || 0) + (Number(it.qty) || 0)) * 1000) / 1000;
      if (it.unavailable === true) t.unavailable = true;
    } else { idx[key] = out.length; out.push(Object.assign({}, it)); }
  });
  return out;
}

function updateOrderStatus_(id, status) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  const rows = sheet.getDataRange().getValues();
  // 🐞 بق حقيقي: الدالة كانت بترجّع { ok: true } دايمًا حتى لو الـ id مش
  // موجود خالص (مثلًا حد أدمن تاني مسحه أو أرشفه في نفس اللحظة) — يعني
  // الواجهة كانت بتصدّق إن التحديث نجح وهو أصلاً مالمسش أي صف. found
  // بترجّع الحقيقة عشان الواجهة تقدر ترجّع الحالة القديمة وتنبّه المستخدم.
  let found = false;
  for (let i = 1; i < rows.length; i++) {
    if (String(rows[i][COL_ID - 1]) !== String(id)) continue;
    found = true;
    sheet.getRange(i + 1, COL_STATUS).setValue(status);
    // وقت التنفيذ: بيتسجّل أول ما الحالة تبقى «تم تنفيذ الطلب» (والحذف التلقائي بيعدّ ٥ دقايق منه)،
    // وبيتمسح لو الأدمن رجّع الحالة لحاجة تانية.
    sheet.getRange(i + 1, COL_DONE_AT).setValue(String(status).trim() === STATUS_DONE ? new Date() : '');
    break;
  }
  markReservedDirty_();   // الحالة اتغيّرت — الحجز لازم يتحدّث
  return { ok: true, found: found };
}

function deleteOrderById_(id) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  const n = sheet.getLastRow() - 1;
  if (n < 1) return { ok: true, deleted: 0 };
  const ids = sheet.getRange(2, COL_ID, n, 1).getValues();
  for (let i = 0; i < ids.length; i++) {
    if (String(ids[i][0]) === String(id)) {
      sheet.deleteRow(i + 2);
      markReservedDirty_();   // بيتزامن في الخلفية خلال دقيقة
      return { ok: true, deleted: 1 };
    }
  }
  return { ok: true, deleted: 0 };
}

// 🔒 حذف طلب من الموزّع نفسه (شاشة "طلباتي") — مش زي deleteOrderById_
// (ده للأدمن بس، توكن أدمن). هنا بنتأكد إن الطلب بتاع نفس صاحب التوكن
// (اسم المستخدم، أو رقم التليفون للطلبات القديمة من غير عمود اسم مستخدم)
// قبل ما نمسح — نفس آلية التحقق من الملكية المستخدمة في تعديل الطلب.
// وبنمنع حذف طلب "تم تنفيذه" فعلاً — ده بقى مسؤولية الأدمن.
function deleteMyOrder_(id, token) {
  const username = userFromToken_(token);
  if (!username) return { ok: false, error: 'unauthorized' };

  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  if (!sheet) return { ok: false, error: 'sheet not found' };
  const n = sheet.getLastRow() - 1;
  if (n < 1) return { ok: false, error: 'الطلب مش موجود' };

  const ids = sheet.getRange(2, COL_ID, n, 1).getValues();
  const myPhone = normalizePhone((userInfo_(username) || {}).phone || '');
  for (let i = 0; i < ids.length; i++) {
    if (String(ids[i][0]) !== String(id)) continue;
    const rowUser = String(sheet.getRange(i + 2, COL_USERNAME).getValue() || '').trim();
    const rowPhone = normalizePhone(sheet.getRange(i + 2, COL_PHONE).getValue());
    const mine = rowUser
      ? (rowUser.toLowerCase() === String(username).trim().toLowerCase())
      : (!!myPhone && rowPhone === myPhone);
    if (!mine) return { ok: false, error: 'unauthorized' };
    const status = String(sheet.getRange(i + 2, COL_STATUS).getValue() || '').trim();
    if (status === STATUS_DONE) return { ok: false, error: 'الطلب ده اتنفّذ بالفعل — متقدرش تحذفه' };
    if (status === STATUS_PREPARING) return { ok: false, error: 'الطلب ده بقى قيد التجهيز — متقدرش تحذفه، كلّم الإدارة' };
    sheet.deleteRow(i + 2);
    markReservedDirty_();
    return { ok: true };
  }
  return { ok: false, error: 'الطلب مش موجود' };
}

/**
 * بيمسح الصفوف المطلوبة **بالمجموعات المتجاورة** بدل صف صف.
 * ٥٠٠ طلب منفَّذ كانوا ٥٠٠ نداء لـ Sheets API — وده بيتخطى حد الـ٦ دقايق
 * ويقع في النص ويسيب البيانات نص ممسوحة. دلوقتي بقوا نداءات معدودة.
 * ⚠️ rowNums لازم تكون أرقام صفوف فعلية (1-indexed).
 */
function deleteRowsBatch_(sheet, rowNums) {
  const sorted = rowNums.slice().sort(function (a, b) { return b - a; });   // من تحت لفوق
  let i = 0;
  while (i < sorted.length) {
    let end = sorted[i];        // أعلى رقم في المجموعة
    let start = end;
    while (i + 1 < sorted.length && sorted[i + 1] === start - 1) { i++; start = sorted[i]; }
    sheet.deleteRows(start, end - start + 1);
    i++;
  }
}

function deleteDeliveredOrders_() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  const n = sheet.getLastRow() - 1;
  if (n < 1) return { ok: true, deleted: 0 };
  const statuses = sheet.getRange(2, COL_STATUS, n, 1).getValues();
  const rows = [];
  for (let i = 0; i < statuses.length; i++) {
    if (String(statuses[i][0]).trim() === STATUS_DONE) rows.push(i + 2);
  }
  if (rows.length) deleteRowsBatch_(sheet, rows);
  markReservedDirty_();   // بيتزامن في الخلفية خلال دقيقة
  return { ok: true, deleted: rows.length };
}

// ═══════════════════════════════════════════════════════════════════
//  الحذف التلقائي للطلبات المنفَّذة بعد ٥ دقايق
// ═══════════════════════════════════════════════════════════════════
// أي طلب حالته «تم تنفيذ الطلب» بيتمسح لوحده بعد ٥ دقايق من وقت التنفيذ (عمود «وقت التنفيذ»).
// الطلبات المنفَّذة القديمة (من قبل الميزة دي، ومالهاش وقت) بتاخد وقت التنفيذ = أول فحص.
// بيشتغل: ١) كل دقيقة بـ trigger (شغّل installTriggers مرة واحدة بعد النشر)،
//         ٢) وكل ما الأدمن يفتح قايمة الطلبات (على الأكتر مرة كل دقيقة) كشبكة أمان.
// يعني الطلب المنفَّذ بيتمسح بين ٥ و٦ دقايق من تنفيذه.
const DONE_TTL_MS_ = 5 * 60 * 1000;   // ٥ دقايق

function purgeDoneOrders_() {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(5000)) return { ok: true, skipped: true };
  try {
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
    if (!sheet) return { ok: true, deleted: 0 };
    const n = sheet.getLastRow() - 1;
    if (n < 1) return { ok: true, deleted: 0 };
    if (!sheet.getRange(1, COL_DONE_AT).getValue()) sheet.getRange(1, COL_DONE_AT).setValue(ORDERS_HEADERS[COL_DONE_AT - 1]);
    const data = sheet.getRange(2, 1, n, COL_DONE_AT).getValues();
    const now = Date.now();
    const toDelete = [], toStamp = [];
    for (let i = 0; i < data.length; i++) {
      if (String(data[i][COL_STATUS - 1]).trim() !== STATUS_DONE) continue;
      const raw = data[i][COL_DONE_AT - 1];
      const ms = raw instanceof Date ? raw.getTime() : (raw ? new Date(raw).getTime() : NaN);
      if (!isFinite(ms)) toStamp.push(i + 2);
      else if (now - ms >= DONE_TTL_MS_) toDelete.push(i + 2);
    }
    toStamp.forEach(function (row) { sheet.getRange(row, COL_DONE_AT).setValue(new Date(now)); });
    if (toDelete.length) { deleteRowsBatch_(sheet, toDelete); markReservedDirty_(); }
    return { ok: true, deleted: toDelete.length, stamped: toStamp.length };
  } finally {
    lock.releaseLock();
  }
}
function purgeDoneOrdersTrigger_() { try { purgeDoneOrders_(); } catch (e) { logError_ && logError_(e); } }
// شبكة أمان: كل ما الأدمن يحمّل الطلبات — بس لو عدّى ٥ دقايق على آخر فحص
function lazyPurgeDone_() {
  try {
    const cache = CacheService.getScriptCache();
    if (cache.get('purgeDoneAt')) return;
    cache.put('purgeDoneAt', '1', 60);
    purgeDoneOrders_();
  } catch (e) {}
}


// ═══════════════════════════════════════════════════════════════════
//  الحسابات: دخول / تسجيل / نسيان الباسورد
// ═══════════════════════════════════════════════════════════════════

function handleLogin(username, password) {
  const uname = String(username || '').trim();
  if (!uname) return { ok: false, reason: 'invalid' };

  // 🔒 حد للمحاولات الفاشلة — من غيره التخمين الآلي مفتوح على الآخر
  if (isLoginLocked_(uname)) return { ok: false, reason: 'locked' };

  const sheet = getUsersSheet_();
  const rows = sheet.getDataRange().getValues();
  for (let i = 1; i < rows.length; i++) {
    if (String(rows[i][0]).trim().toLowerCase() !== uname.toLowerCase()) continue;

    if (!verifyPw_(rows[i][1], password)) {
      noteLoginFail_(uname);
      return { ok: false, reason: 'invalid' };
    }
    const status = String(rows[i][5] || '').trim();
    if (status !== 'مفعل') return { ok: false, reason: 'pending' };

    clearLoginFails_(uname);
    // ترقية صامتة: الباسورد كان نص صريح → نحوّله لـ hash دلوقتي
    if (!isHashedPw_(rows[i][1])) {
      try {
        const upgraded = makePwHash_(password);
        sheet.getRange(i + 1, 2).setValue(upgraded);
        rows[i][1] = upgraded; // Bind the token to the credential actually saved.
      } catch (e) {}
    }

    // النوع (موزع/عميل) في العمود الثامن — لو فاضي (حسابات قديمة) يبقى "موزع"
    const distType = String(rows[i][7] || '').trim() === 'عميل' ? 'عميل' : 'موزع';
    const realUsername = String(rows[i][0]).trim();
    return {
      ok: true,
      username: realUsername,
      distName: rows[i][2] || '',
      distRegion: rows[i][3] || '',
      distPhone: String(rows[i][4] == null ? '' : rows[i][4]),
      distType: distType,
      token: signToken_('user', realUsername, TTL_USER_MS, rows[i][1])
    };
  }
  noteLoginFail_(uname);
  return { ok: false, reason: 'invalid' };
}

function handleRegister(data) {
  if (isRegisterFlooded_()) return json_({ ok: false, reason: 'flooded' });
  noteRegisterAttempt_();
  const sheet = getUsersSheet_();
  const username = String(data.username || '').trim();
  const password = String(data.password || '');
  if (!username || !password) return json_({ ok: false, reason: 'missing' });
  if (isBadUsername_(username)) return json_({ ok: false, reason: 'invalid_username' });

  const rows = sheet.getDataRange().getValues();
  for (let i = 1; i < rows.length; i++) {
    if (String(rows[i][0]).trim().toLowerCase() === username.toLowerCase()) {
      return json_({ ok: false, reason: 'exists' });
    }
  }
  const distType = (String(data.distType || '').trim() === 'عميل') ? 'عميل' : 'موزع';
  const newRow = sheet.getLastRow() + 1;
  sheet.getRange(newRow, 5).setNumberFormat('@');
  sheet.appendRow([
    username, makePwHash_(password), cellSafe_(data.distName), cellSafe_(data.distRegion),
    String(data.distPhone || ''), 'قيد المراجعة', new Date(), distType
  ]);
  return json_({ ok: true });
}

// الموزع بيكتب الباسورد الجديد اللي عايزه، بس مابيتفعّلش على طول — بيتسجّل
// "قيد المراجعة" وبيوصل إشعار واتساب للأدمن، ولازم موافقة من داخل التطبيق.
// ⚠️ الباسورد بيتخزّن **مشفّر** في شيت الطلبات — قبل كده كان نص صريح وبيفضل
// موجود في الشيت للأبد حتى بعد الموافقة.
function handleRequestPasswordReset(data) {
  const username = String(data.username || '').trim();
  const newPassword = String(data.newPassword || '');
  if (!username || !newPassword) return json_({ ok: false, error: 'بيانات ناقصة' });

  const users = getUsersSheet_().getDataRange().getValues();
  let found = false;
  for (let i = 1; i < users.length; i++) {
    if (String(users[i][0]).trim().toLowerCase() === username.toLowerCase()) { found = true; break; }
  }
  if (!found) return json_({ ok: false, error: 'اسم المستخدم مش موجود' });

  getPwRequestsSheet_().appendRow([
    Utilities.getUuid(), new Date(), username, makePwHash_(newPassword), 'قيد المراجعة'
  ]);
  return json_({ ok: true });
}

// شيت طلبات الباسورد مالوش عمود "اسم الموزع" (اسم المستخدم بس)، وده مش واضح
// كفاية للأدمن. بندوّر على اسم الموزّع من شيت المستخدمين ونرجّعه معاه.
function listPwRequests_() {
  const rows = getPwRequestsSheet_().getDataRange().getValues();
  rows.shift();
  const usersRows = getUsersSheet_().getDataRange().getValues();
  const distNameByUsername_ = {};
  usersRows.forEach(function (r) {
    const u = String(r[0] || '').trim().toLowerCase();
    if (u) distNameByUsername_[u] = String(r[2] || '');
  });
  const out = [];
  rows.forEach(function (r) {
    if (String(r[4] || '').trim() !== 'قيد المراجعة') return;
    const username = String(r[2] || '');
    out.push({
      id: String(r[0]),
      date: r[1] ? new Date(r[1]).toLocaleString('ar-EG') : '',
      username: username,
      distName: distNameByUsername_[username.trim().toLowerCase()] || ''
    });
  });
  return out.reverse();
}

// موافقة: بينقل الباسورد الجديد (المشفّر) لشيت المستخدمين، وبيمسحه من شيت
// الطلبات عشان مايفضلش متخزّن في مكانين. رفض: بيقفل الطلب من غير تغيير.
function decidePwRequest_(id, approve) {
  const sheet = getPwRequestsSheet_();
  const rows = sheet.getDataRange().getValues();
  for (let i = 1; i < rows.length; i++) {
    if (String(rows[i][0]) !== String(id)) continue;
    const username = String(rows[i][2] || '');
    const newPassword = String(rows[i][3] || '');
    if (approve) {
      // الطلبات القديمة كانت بتتخزن نص صريح — نشفّرها دلوقتي قبل الحفظ
      const toStore = isHashedPw_(newPassword) ? newPassword : makePwHash_(newPassword);
      const users = getUsersSheet_();
      const urows = users.getDataRange().getValues();
      for (let j = 1; j < urows.length; j++) {
        if (String(urows[j][0]).trim().toLowerCase() === username.trim().toLowerCase()) {
          revokeUserTokens_(username);
          users.getRange(j + 1, 2).setValue(toStore);
          clearLoginFails_(username);
          break;
        }
      }
    }
    sheet.getRange(i + 1, 4).setValue('———');   // مانحتفظش بالباسورد بعد القرار
    sheet.getRange(i + 1, 5).setValue(approve ? 'تمت الموافقة' : 'مرفوض');
    return true;
  }
  return false;
}

// شيت المستخدمين: A=username, B=password, C=distName, D=distRegion,
// E=distPhone, F=status, G=date, H=distType. "قيد المراجعة" = محتاج موافقة.
function listRegRequests_() {
  const rows = getUsersSheet_().getDataRange().getValues();
  const out = [];
  for (let i = 1; i < rows.length; i++) {
    if (String(rows[i][5] || '').trim() !== 'قيد المراجعة') continue;
    out.push({
      username: String(rows[i][0] || ''),
      distName: String(rows[i][2] || ''),
      distRegion: String(rows[i][3] || ''),
      distPhone: String(rows[i][4] == null ? '' : rows[i][4]),
      distType: String(rows[i][7] || 'موزع'),
      date: rows[i][6] ? new Date(rows[i][6]).toLocaleString('ar-EG') : ''
    });
  }
  return out.reverse();
}

// موافقة: الحالة → "مفعل". رفض: → "مرفوض" (الصف يفضل للمرجع، مفيش حذف نهائي).
function decideRegRequest_(username, approve) {
  const sheet = getUsersSheet_();
  const rows = sheet.getDataRange().getValues();
  for (let i = 1; i < rows.length; i++) {
    if (String(rows[i][0]).trim().toLowerCase() === String(username).trim().toLowerCase()) {
      // Revoke before changing state, so re-approval cannot revive old sessions.
      revokeUserTokens_(username);
      sheet.getRange(i + 1, 6).setValue(approve ? 'مفعل' : 'مرفوض');
      return true;
    }
  }
  return false;
}


// ═══════════════════════════════════════════════════════════════════
//  إشعارات واتساب (CallMeBot) — اتلغت بالكامل بطلب صريح
// ═══════════════════════════════════════════════════════════════════
//
// ⚠️ كانت هنا منظومة طابور (شيت "طابور إشعارات واتساب" + trigger كل دقيقة)
// بتبعت عبر CallMeBot. اتلغت خالص — مفيش أي إرسال واتساب تلقائي (لا للأدمن
// ولا للموزّع) دلوقتي. الموزّع/الأدمن لسه يقدر يستخدم أزرار المشاركة
// اليدوية العادية (wa.me) اللي مش مرتبطة بـ CallMeBot خالص. لو حابب ترجّع
// الميزة يومًا ما، هتحتاج خدمة بديلة (رسمية زي WhatsApp Business API، أو
// أي حاجة غير CallMeBot) — شوف تاريخ git للكود القديم لو محتاجه كمرجع.
//
// شيت "طابور إشعارات واتساب" ممكن يتمسح يدويًا من الجوجل شيت — مش بيتلمس
// تلقائيًا هنا عشان مانمسحش بيانات من غير طلب صريح.

// بتتنادى من trigger الدقيقة — نفس الوظيفة اللي كانت مركوبة على trigger
// الواتساب القديم، دلوقتي لوحدها.
function minuteSync_() {
  syncReservedIfDirty_();
}


// ═══════════════════════════════════════════════════════════════════
//  إشعارات المتصفح (Web Push) — متوقفة حاليًا
// ═══════════════════════════════════════════════════════════════════
//
// ⚠️ النسخة القديمة كانت بتبعت الـ payload خام لـ endpoint الاشتراك من غير
// حاجتين إجباريتين في بروتوكول Web Push:
//   ١) هيدر Authorization فيه VAPID JWT موقّع (RFC 8292)
//   ٢) تشفير الـ payload بـ aes128gcm (RFC 8291)
// خدمة الـ push كانت بترد 401/400 دايمًا — يعني **مفيش ولا إشعار واحد وصل
// لأي مستخدم** من يوم ما الميزة اتكتبت. وأسوأ: الكود كان بيعتبر الرد ده
// اشتراك ميت ويمسحه.
//
// Apps Script مافيهوش ECDSA signing ولا AES-GCM ولا ECDH، فتنفيذ البروتوكول
// صح مش ممكن هنا. فوقفنا الإرسال، والاعتماد بقى على واتساب (اللي شغال فعلاً).
//
// لو عايز الإشعارات تشتغل بجد لاحقًا: استخدم خدمة وسيطة بتتنادى بـ
// UrlFetchApp عادي — Firebase Cloud Messaging HTTP v1 أو OneSignal —
// وسيب savePushSub_ زي ما هي لأنها بتجمّع الاشتراكات أصلاً.

function savePushSub_(username, subJson) {
  const sheet = getUsersSheet_();
  const rows = sheet.getDataRange().getValues();
  for (let i = 1; i < rows.length; i++) {
    if (String(rows[i][0]).trim().toLowerCase() === String(username).trim().toLowerCase()) {
      sheet.getRange(i + 1, 11).setValue(subJson ? JSON.stringify(subJson) : '');
      return true;
    }
  }
  return false;
}


// ═══════════════════════════════════════════════════════════════════
//  حساب البضاعة المحجوزة
// ═══════════════════════════════════════════════════════════════════
//
// بيبني خريطة: اسم الصنف → الكمية المحجوزة (بالعود/القطعة) من الطلبات اللي
// لسه ماتنفذتش **ومخزنها طنطا بس**. أي طلب من مخزن تاني مابيحجزش خالص.
// أول ما الطلب يتنفذ أو يتحذف أو يتأرشف، الحجز بيروح لوحده.

function findHeaderCol_(headers, name) {
  for (let i = 0; i < headers.length; i++) {
    if (String(headers[i] || '').trim() === name) return i;
  }
  return -1;
}

/** محتوى اللفة لكل صنف — بيقرا عمودين بس (A و D) مش الشيت كله. */
function catalogUnitMap_(csheet) {
  const n = csheet.getLastRow() - 1;
  const map = {};
  if (n < 1) return map;
  const vals = csheet.getRange(2, 1, n, 4).getValues();
  for (let i = 0; i < vals.length; i++) {
    const k = String(vals[i][0] || '').trim();
    if (k) map[k] = Number(vals[i][3]) || 1;
  }
  return map;
}

function buildReservedMap_(csheet) {
  const reserved = {};
  try {
    const unitByName = csheet ? catalogUnitMap_(csheet) : {};

    const osheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
    if (!osheet) return reserved;
    const n = osheet.getLastRow() - 1;
    if (n < 1) return reserved;

    // ⚡ الأعمدة المطلوبة بس (الحالة، الأصناف، المخزن) بدل الشيت كله.
    // القراءة الكاملة كانت بتجيب ١٢ عمود × كل الطلبات في كل عملية حفظ.
    const rows = osheet.getRange(2, COL_STATUS, n, 3).getValues();
    const BIG_UNITS = ['لفة', 'كرتونة'];

    for (let i = 0; i < rows.length; i++) {
      const status = String(rows[i][0] || '').trim();
      // 🐞 إصلاح الحجز المزدوج: الطلب اللي اتعدّل بيسيب صف قديم حالته "مُعدّل"
      // وصف جديد حالته "تم استلام الطلب". الكود القديم كان بيستثني المنفَّذ بس،
      // فالاتنين كانوا بيتحسبوا → كل تعديل بيحجز ضعف الكمية، ولو اتعدّل ٣ مرات
      // بيحجز ٤ أضعاف. أصناف متاحة فعلاً كانت بتبان "مفيش رصيد" بسبب ده.
      if (status === STATUS_DONE || status === STATUS_EDITED) continue;
      if (String(rows[i][2] || '').trim() !== RESERVED_WAREHOUSE_) continue;

      let items = [];
      try { items = rows[i][1] ? JSON.parse(rows[i][1]) : []; } catch (e) { continue; }
      if (!Array.isArray(items)) continue;

      items.forEach(function (it) {
        const name = String(it.name || it.product || '').trim();
        if (!name) return;
        const qty = Number(it.qty) || 0;
        if (qty <= 0) return;
        const content = unitByName[name] || 1;
        reserved[name] = (reserved[name] || 0) +
          (BIG_UNITS.indexOf(String(it.unitType || '')) >= 0 ? qty * content : qty);
      });
    }
  } catch (e) {
    // خريطة فاضية = مفيش حجز، والرصيد يظهر زي ما هو — أأمن من إننا نوقف كل حاجة
    logError_('buildReservedMap_', e, '');
  }
  return reserved;
}

/**
 * بيكتب "بضاعة محجوزة" و"رصيد متبقي" في شيت الأصناف.
 * "الرصيد" يفضل رقمك إنت زي ما هو — إحنا بنكتب في العمودين الجداد بس:
 *   بضاعة محجوزة = مجموع كميات الطلبات اللي لسه ماتنفذتش (بالعود/القطعة)
 *   رصيد متبقي   = الرصيد − بضاعة محجوزة (مش أقل من صفر)
 * لو العمودين مش موجودين بالاسم بالظبط، بيتخطى من غير أي خطأ.
 */
function syncReservedColumns_() {
  // ⚠️ getDocumentLock مش getScriptLock: العدّاد (getNextOrderNumber_) بياخد
  // الـ script lock، ولو استخدمنا نفس النوع هنا كان الاتنين بيزاحموا بعض
  // ويأخّروا الطلب. ودلوقتي مابنستناش خالص (tryLock(0)) — لو مشغول نسيبها
  // للمرة الجاية، والـ trigger كل ١٠ دقايق بيضمن إنها تحصل.
  const lock = LockService.getDocumentLock();
  if (!lock.tryLock(0)) { markReservedDirty_(); return; }
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const csheet = ss.getSheetByName(CATALOG_SHEET_NAME);
    if (!csheet) return;

    const lastRow = csheet.getLastRow();
    const lastCol = csheet.getLastColumn();
    if (lastRow < 2 || lastCol < 1) return;

    const headers = csheet.getRange(1, 1, 1, lastCol).getValues()[0];
    const stockCol = findHeaderCol_(headers, 'الرصيد');
    const reservedCol = findHeaderCol_(headers, 'بضاعة محجوزة');
    const remainCol = findHeaderCol_(headers, 'رصيد متبقي');
    if (stockCol < 0 || reservedCol < 0 || remainCol < 0) return;   // الأعمدة مش موجودة

    const n = lastRow - 1;
    const names = csheet.getRange(2, 1, n, 1).getValues();
    const stocks = csheet.getRange(2, stockCol + 1, n, 1).getValues();
    const reserved = buildReservedMap_(csheet);

    const reservedOut = [], remainOut = [];
    for (let i = 0; i < n; i++) {
      const name = String(names[i][0] || '').trim();
      if (!name) { reservedOut.push(['']); remainOut.push(['']); continue; }
      const rawStockText = String(stocks[i][0] == null ? '' : stocks[i][0]).trim();
      const rawStock = (rawStockText !== '' && rawStockText !== 'غير متوفر') ? (Number(rawStockText) || 0) : null;
      const held = reserved[name] || 0;
      reservedOut.push([held]);
      remainOut.push([rawStock === null ? '' : Math.max(0, rawStock - held)]);
    }

    csheet.getRange(2, reservedCol + 1, n, 1).setValues(reservedOut);
    csheet.getRange(2, remainCol + 1, n, 1).setValues(remainOut);
  } catch (e) {
    // مانوقفش أي عملية حفظ/تعديل/حذف بسبب فشل في تحديث عمودين إضافيين
    logError_('syncReservedColumns_', e, '');
  } finally {
    try { lock.releaseLock(); } catch (e) {}
  }
}

// ═══════════════════════════════════════════════════════════════════
//  ⚡ ليه المزامنة مابقتش جوه مسار الحفظ؟
// ═══════════════════════════════════════════════════════════════════
//
// syncReservedColumns_ بتقرا شيت الأصناف كله + شيت الطلبات كله وبتكتب عمودين.
// ده ٨-١٠ نداءات لـ Sheets API، وكل نداء بياخد جزء من الثانية — يعني ثواني
// مضافة على **كل** طلب بيتبعت، والموزّع قاعد مستني الشاشة.
//
// وأسوأ: getNextOrderNumber_ بتاخد الـ script lock، والمزامنة بتاخد نفس النوع،
// والـ trigger الدوري كمان. فلو اتصادفوا، الطلب بيستنى الـ lock لحد ٢٥ ثانية.
//
// الحل: الحفظ بيعلّم "فيه تغيير" وبيرجّع فورًا، والمزامنة بتحصل في الخلفية
// خلال دقيقة (مع trigger الواتساب اللي شغّال كل دقيقة أصلاً). الرصيد المعروض
// بيتأخر دقيقة على الأكتر — وده مقبول تمامًا في الشغل، مقابل إن إرسال الطلب
// بقى فوري.

const RESERVED_DIRTY_KEY = 'RESERVED_DIRTY';

function markReservedDirty_() {
  try { props_().setProperty(RESERVED_DIRTY_KEY, '1'); } catch (e) {}
}

/** بتتنادى من trigger الدقيقة — بتزامن بس لو فيه تغيير فعلاً. */
function syncReservedIfDirty_() {
  try {
    if (props_().getProperty(RESERVED_DIRTY_KEY) !== '1') return;
    props_().deleteProperty(RESERVED_DIRTY_KEY);
    // 🐞 بق حقيقي كان هنا: السطر ده كان `markReservedDirty_()` بدل
    // `syncReservedColumns_()` — يعني الدالة كانت بس بتمسح العلامة وترجع
    // تحطها تاني من غير ما تعمل المزامنة الفعلية خالص. النتيجة: تحديث
    // "بضاعة محجوزة"/"رصيد متبقي" في شيت الأصناف كان بيتأخر فعليًا لحد
    // ١٠ دقايق (عن طريق reconcileReserved المنفصلة) بدل دقيقة واحدة زي
    // الموثّق فوق. لو syncReservedColumns_ لقت القفل مشغول، هي نفسها
    // بتعمل markReservedDirty_() وترجع (شوف تعليقها) — فمفيش داعي نكررها هنا.
    syncReservedColumns_();
  } catch (e) { logError_('syncReservedIfDirty_', e, ''); }
}

/** شبكة أمان: كل ١٠ دقايق بتعيد الحساب كامل، حتى لو العلامة ضاعت. */
function reconcileReserved() { syncReservedColumns_(); }

/** 🔧 شغّلها يدويًا أي وقت لو عايز تحسب المحجوز من الأول فورًا. */
function recalculateReservedNow() {
  syncReservedColumns_();
  return 'اتحسب المحجوز والرصيد المتبقي من الأول.';
}


// ═══════════════════════════════════════════════════════════════════
//  الأصناف (الكتالوج)
// ═══════════════════════════════════════════════════════════════════
//
// شيت الأصناف: A=name(المفتاح الفريد), B=main, C=sub, D=unit(المحتوى),
// E=product, F=color, G=price, H=stock(الرصيد), I=available('لا'=موقوف).

function updateCatalogItem_(data) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(CATALOG_SHEET_NAME);
  if (!sheet) return false;
  const n = sheet.getLastRow() - 1;
  if (n < 1) return false;
  const names = sheet.getRange(2, 1, n, 1).getValues();
  for (let i = 0; i < names.length; i++) {
    if (String(names[i][0]).trim() !== String(data.name).trim()) continue;
    const r = i + 2;
    if (data.unit !== undefined && data.unit !== '') sheet.getRange(r, 4).setValue(Number(data.unit) || 1);
    if (data.price !== undefined) sheet.getRange(r, 7).setValue(data.price === '' ? '' : Number(data.price));
    if (data.stock !== undefined) sheet.getRange(r, 8).setValue(data.stock === '' ? '' : Number(data.stock));
    if (data.available !== undefined) sheet.getRange(r, 9).setValue(data.available ? '' : 'لا');
    markReservedDirty_();   // بيتزامن في الخلفية خلال دقيقة
    return true;
  }
  return false;
}

// 🧭 نقل صنف (بكل ألوانه) لنوع تاني: مفصلي / جرار / أخرى — بيتكتب في عمود «النوع» (بيتعمل لو مش موجود).
// النوع الفاضي = التصنيف التلقائي (من اسم الصنف). بيتطبّق على كل صفوف نفس الـ main + الـ product.
function setProductType_(main, product, type) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(CATALOG_SHEET_NAME);
  if (!sheet) return false;
  const t = String(type == null ? '' : type).trim();
  if (t && ['مفصلي', 'جرار', 'أخرى'].indexOf(t) < 0) return false;
  const lastCol = Math.max(sheet.getLastColumn(), 9);
  const headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  let col = findHeaderCol_(headers, 'النوع');
  if (col < 0) {
    col = sheet.getLastColumn();                // أول عمود فاضي بعد آخر عمود موجود
    sheet.getRange(1, col + 1).setValue('النوع');
  }
  const n = sheet.getLastRow() - 1;
  if (n < 1) return false;
  const vals = sheet.getRange(2, 1, n, 5).getValues();     // A..E (B=main, E=product)
  let hit = 0;
  for (let i = 0; i < n; i++) {
    if (String(vals[i][1]).trim() === String(main).trim() && String(vals[i][4] || vals[i][0]).trim() === String(product).trim()) {
      sheet.getRange(i + 2, col + 1).setValue(t);
      hit++;
    }
  }
  return hit > 0;
}

function addCatalogItem_(data) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(CATALOG_SHEET_NAME);
  if (!sheet) return false;
  const name = String(data.name || data.product || '').trim();
  if (!name) return false;
  // امنع تكرار نفس الاسم (المفتاح الفريد) بصنف جديد بالغلط
  const n = sheet.getLastRow() - 1;
  if (n > 0) {
    const names = sheet.getRange(2, 1, n, 1).getValues();
    for (let i = 0; i < names.length; i++) {
      if (String(names[i][0]).trim() === name) return false;
    }
  }
  sheet.appendRow([
    name, data.main || '', data.sub || '', Number(data.unit) || 1,
    data.product || name, data.color || '',
    (data.price === '' || data.price == null) ? '' : Number(data.price),
    (data.stock === '' || data.stock == null) ? '' : Number(data.stock),
    data.available ? '' : 'لا'
  ]);
  return true;
}

// mode='full': بيحدّث كل الأعمدة لصف موجود، وبيضيف صف جديد لو الاسم مش موجود.
// mode='stock': بيحدّث عمود الرصيد بس، وبيسجّل الأسامي المش موجودة كـ notFound.
// ⚡ بيقرا ويكتب بالكتلة (بدل نداء لكل خلية) — رفع ١٠٠٠ صنف كان بيتخطى حد
// الـ٦ دقايق بتاع Apps Script ويقع في النص.
function bulkUpdateCatalog_(rows, mode) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(CATALOG_SHEET_NAME);
  if (!sheet) return { updated: 0, added: 0, notFound: [] };

  const n = Math.max(0, sheet.getLastRow() - 1);
  const width = 9;
  const data = n > 0 ? sheet.getRange(2, 1, n, width).getValues() : [];
  const nameToIdx = {};
  for (let i = 0; i < data.length; i++) {
    const k = String(data[i][0] || '').trim();
    if (k && !(k in nameToIdx)) nameToIdx[k] = i;
  }

  let updated = 0, added = 0;
  const notFound = [], toAppend = [];

  (rows || []).forEach(function (row) {
    const name = String(row.name || '').trim();
    if (!name) return;
    const idx = nameToIdx[name];
    if (idx !== undefined) {
      // 🐞 بق حقيقي: هنا كان أي mode غير 'stock' (حتى لو قيمة غريبة/غير
      // متوقعة) بياخد مسار "full" كامل بالغلط، بينما الصنف الجديد تحت
      // بيتضاف بس لو mode==='full' بالظبط — عدم تناسق كان ممكن يمسح أعمدة
      // صنف موجود (سعر/رصيد...) لو وصل mode غريب، رغم إن الواجهة حاليًا
      // بتبعت 'full' أو 'stock' بس. بقى الشرط صريح زي الطرف التاني بالظبط.
      if (mode === 'stock') {
        if (row.stock !== undefined) data[idx][7] = (row.stock === '' ? '' : Number(row.stock));
      } else if (mode === 'full') {
        data[idx][1] = row.main || '';
        data[idx][2] = row.sub || '';
        data[idx][3] = Number(row.unit) || 1;
        data[idx][4] = row.product || name;
        data[idx][5] = row.color || '';
        data[idx][6] = (row.price === '' || row.price == null) ? '' : Number(row.price);
        data[idx][7] = (row.stock === '' || row.stock == null) ? '' : Number(row.stock);
        data[idx][8] = row.disabled ? 'لا' : '';
      } else {
        return;   // mode غير معروف — منلمسش الصف خالص
      }
      updated++;
    } else if (mode === 'full') {
      toAppend.push([
        name, row.main || '', row.sub || '', Number(row.unit) || 1,
        row.product || name, row.color || '',
        (row.price === '' || row.price == null) ? '' : Number(row.price),
        (row.stock === '' || row.stock == null) ? '' : Number(row.stock),
        row.disabled ? 'لا' : ''
      ]);
      added++;
    } else {
      notFound.push(name);   // وضع "الرصيد بس" والصنف مش موجود — نبلّغ عنه
    }
  });

  if (updated && data.length) sheet.getRange(2, 1, data.length, width).setValues(data);
  if (toAppend.length) sheet.getRange(sheet.getLastRow() + 1, 1, toAppend.length, width).setValues(toAppend);
  markReservedDirty_();   // بيتزامن في الخلفية خلال دقيقة
  return { updated: updated, added: added, notFound: notFound };
}

// ⚠️ بطلب صريح: زرارين منفصلين — واحد يصفّر الرصيد لكل الأصناف، والتاني
// يصفّر (يخفي) السعر لكل الأصناف — كل واحد لوحده، من غير ما يأثر على التاني.
// col: 7=السعر (G), 8=الرصيد (H). بيكتب عمود واحد بس بالكتلة، وبيسيب باقي
// أعمدة الصنف (الاسم/القطاع/اللون/موقوف) زي ما هي.
function clearAllCatalogColumn_(col) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(CATALOG_SHEET_NAME);
  if (!sheet) return { cleared: 0 };
  const n = Math.max(0, sheet.getLastRow() - 1);
  if (n < 1) return { cleared: 0 };
  const blank = [];
  for (let i = 0; i < n; i++) blank.push(['']);
  sheet.getRange(2, col, n, 1).setValues(blank);
  markReservedDirty_();
  return { cleared: n };
}

// 💲 تصفير السعر (عمود G) لمجموعات محددة بس. كل عنصر: { main, sub } —
// الصنف بيتصفّر لو قطاعه (عمود B) وتصنيفه الفرعي (عمود C) مطابقين لواحد منهم.
function clearCatalogPricesByGroups_(groups) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(CATALOG_SHEET_NAME);
  if (!sheet || !groups || !groups.length) return { cleared: 0 };
  const n = Math.max(0, sheet.getLastRow() - 1);
  if (n < 1) return { cleared: 0 };
  const want = {};
  groups.forEach(function (g) { want[String(g.main || '').trim() + '||' + String(g.sub || '').trim()] = true; });
  const bc = sheet.getRange(2, 2, n, 2).getValues();   // B=القطاع, C=التصنيف الفرعي
  const cells = [];
  for (let i = 0; i < n; i++) {
    const key = String(bc[i][0] || 'أخرى').trim() + '||' + String(bc[i][1] || '').trim();
    if (want[key]) cells.push('G' + (i + 2));
  }
  if (cells.length) {
    sheet.getRangeList(cells).setValue('');
    markReservedDirty_();
  }
  return { cleared: cells.length };
}

// تصدير كامل للأصناف — عشان تراجعهم/تعدّلهم في إكسيل وترفعهم تاني بنفس الشكل
function exportCatalogRows_() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(CATALOG_SHEET_NAME);
  if (!sheet) return [];
  const n = sheet.getLastRow() - 1;
  if (n < 1) return [];
  return sheet.getRange(2, 1, n, 9).getValues()
    .filter(function (r) { return r[0]; })
    .map(function (r) {
      return {
        name: r[0], main: r[1], sub: r[2], unit: r[3], product: r[4], color: r[5],
        price: r[6], stock: r[7], disabled: (r[8] && String(r[8]).trim() === 'لا')
      };
    });
}

function buildCatalogPayload_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const csheet = ss.getSheetByName(CATALOG_SHEET_NAME);
  const dsheet = ss.getSheetByName(DISCOUNT_SHEET_NAME);

  // الرصيد في عمود H جوه شيت الأصناف نفسه (جمب السعر) — بدل مطابقة الاسم مع
  // شيت تاني. خلية فاضية أو "غير متوفر" = مفيش رصيد. عمود I = تعطيل يدوي.
  //
  // الأولوية: لو عمود "رصيد متبقي" موجود وفيه رقم، نقراه مباشرة (محسوب
  // بالفعل من syncReservedColumns_). لو فاضي، نحسب المحجوز في نفس اللحظة.
  let items = [];
  if (csheet) {
    const lastRow = csheet.getLastRow();
    const lastCol = csheet.getLastColumn();
    if (lastRow >= 2) {
      const headers = csheet.getRange(1, 1, 1, lastCol).getValues()[0];
      const remainColIdx = findHeaderCol_(headers, 'رصيد متبقي');
      const typeColIdx = findHeaderCol_(headers, 'النوع');   // تصنيف يدوي (مفصلي / جرار / أخرى) — بيتحدد من التطبيق بزرار «نقل»
      const rows = csheet.getRange(2, 1, lastRow - 1, lastCol).getValues();
      // ⚡ المحجوز بيتحسب **عند الحاجة بس**. في الحالة الطبيعية عمود "رصيد
      // متبقي" مليان بأرقام جاهزة، فمش محتاجين نقرا شيت الطلبات كله أصلاً.
      // قبل كده كان بيتحسب دايمًا — يعني كل مرة أي موزّع بيفتح التطبيق، السيرفر
      // بيقرا كل الطلبات على الفاضي. ده كان أبطأ حاجة في فتح التطبيق.
      let _reservedCache = null;
      const reserved_ = () => (_reservedCache || (_reservedCache = buildReservedMap_(csheet)));

      items = rows.filter(function (r) { return r[0]; }).map(function (r) {
        const adminAvailable = !(r[8] && String(r[8]).trim() === 'لا');
        const stockText = String(r[7] == null ? '' : r[7]).trim();
        const rawStock = (stockText !== '' && stockText !== 'غير متوفر') ? (Number(stockText) || 0) : null;

        let stockQty;
        if (remainColIdx >= 0) {
          const remainText = String(r[remainColIdx] == null ? '' : r[remainColIdx]).trim();
          if (remainText !== '') {
            stockQty = Math.max(0, Number(remainText) || 0);
          } else {
            const held = reserved_()[String(r[0]).trim()] || 0;
            stockQty = (rawStock === null) ? null : Math.max(0, rawStock - held);
          }
        } else {
          const held = reserved_()[String(r[0]).trim()] || 0;
          stockQty = (rawStock === null) ? null : Math.max(0, rawStock - held);
        }

        return {
          name: r[0], main: r[1], sub: r[2],
          type: typeColIdx >= 0 ? String(r[typeColIdx] == null ? '' : r[typeColIdx]).trim() : '',
          unit: Number(r[3]) || 1, product: r[4] || r[0], color: r[5] || '',
          price: (r[6] === '' || r[6] === null || r[6] === undefined) ? null : Number(r[6]),
          // available = الأدمن عطّل الصنف يدويًا (عمود I = "لا")
          // inStock/stock = من "رصيد متبقي" أو "الرصيد" ناقص المحجوز
          available: adminAvailable,
          inStock: (stockQty !== null) && stockQty > 0,
          stock: stockQty
        };
      });
    }
  }

  let discounts = {};
  if (dsheet) {
    const drows = dsheet.getDataRange().getValues();
    drows.shift();
    drows.forEach(function (r) {
      if (!r[0]) return;
      let v = Number(r[1]) || 0;
      // لو الخلية متنسقة كنسبة مئوية (%)، getValues() بترجع الكسر العشري
      // (0.15) مش الرقم (15) — نحوّله هنا لنسبة مئوية عادية.
      if (v > 0 && v < 1) v = v * 100;
      discounts[r[0]] = v;
    });
  }
  return { items: items, discounts: discounts, version: APP_VERSION, displayGroupsVersion:2, displayGroups:readAccDisplayGroups_(), customGroups:readAccCustomGroups_() };
}


// ═══════════════════════════════════════════════════════════════════
//  تحويل صف لطلب
// ═══════════════════════════════════════════════════════════════════

function rowToOrder(r) {
  // ⚠️ جوجل شيتس بيرجّع رقم الهاتف كـ Number (وبيشيل الصفر اللي في الأول).
  // لازم نحوّله لنص هنا، وإلا التطبيق بيحاول يعمل .trim() على رقم ويقع.
  //
  // ⚠️ وأهم: JSON.parse على صف واحد باظ كان بيرمي خطأ ويفشّل الطلب كله —
  // فكل الطلبات تختفي من الشاشة بسبب صف واحد. دلوقتي الصف الباظ بيرجع
  // بأصناف فاضية وباقي الطلبات تظهر عادي.
  let items = [];
  try { items = r[COL_ITEMS - 1] ? JSON.parse(r[COL_ITEMS - 1]) : []; } catch (e) { items = []; }
  if (!Array.isArray(items)) items = [];

  let ts = new Date(r[COL_TS - 1]).getTime();
  if (!isFinite(ts)) ts = 0;

  // ✏️ علامة التعديل مخبّية في أول الملاحظات (شوف EDIT_MARK_PREFIX_ في
  // saveOrder_) — بنشيلها من هنا قبل ما الملاحظة توصل للموزع/الأدمن،
  // ونرجّع رقم الطلب القديم في editedFrom عشان الواجهة تعرض تاج "معدّل".
  let noteRaw = String(r[COL_NOTE - 1] == null ? '' : r[COL_NOTE - 1]);
  let editedFrom = '';
  if (noteRaw.indexOf(EDIT_MARK_PREFIX_) === 0) {
    const endIdx = noteRaw.indexOf(EDIT_MARK_SUFFIX_, EDIT_MARK_PREFIX_.length);
    if (endIdx > -1) {
      editedFrom = noteRaw.slice(EDIT_MARK_PREFIX_.length, endIdx);
      noteRaw = noteRaw.slice(endIdx + EDIT_MARK_SUFFIX_.length);
    }
  }

  return {
    id: String(r[COL_ID - 1]),
    ts: ts,
    distName: String(r[COL_NAME - 1] == null ? '' : r[COL_NAME - 1]),
    distRegion: String(r[COL_REGION - 1] == null ? '' : r[COL_REGION - 1]),
    distPhone: String(r[COL_PHONE - 1] == null ? '' : r[COL_PHONE - 1]),
    note: noteRaw,
    editedFrom: editedFrom,
    status: String(r[COL_STATUS - 1] == null ? '' : r[COL_STATUS - 1]),
    items: items,
    warehouse: String(r[COL_WAREHOUSE - 1] == null ? '' : r[COL_WAREHOUSE - 1]),
    orderNo: String(r[COL_ORDERNO - 1] == null ? '' : r[COL_ORDERNO - 1]),
    username: String(r[COL_USERNAME - 1] == null ? '' : r[COL_USERNAME - 1])
  };
}

function normalizePhone(p) {
  return String(p || '').replace(/\D/g, '');
}

/** بيرجّع بيانات الموزّع (الهاتف/النوع) من اسم المستخدم. */
function userInfo_(username) {
  const rows = getUsersSheet_().getDataRange().getValues();
  for (let i = 1; i < rows.length; i++) {
    if (String(rows[i][0]).trim().toLowerCase() === String(username).trim().toLowerCase()) {
      return {
        username: String(rows[i][0]).trim(),
        distName: String(rows[i][2] || ''),
        phone: normalizePhone(rows[i][4]),
        status: String(rows[i][5] || '').trim()
      };
    }
  }
  return null;
}


// ═══════════════════════════════════════════════════════════════════
//  doGet — قراءة بس
// ═══════════════════════════════════════════════════════════════════

function doGet(e) {
  try {
    return doGetInner_(e);
  } catch (err) {
    logError_('doGet', err, e && e.parameter ? JSON.stringify(e.parameter) : '');
    return json_({ ok: false, error: String(err) });
  }
}

function doGetInner_(e) {
  const action = e.parameter.action;
  const token = e.parameter.token;

  // افتح ?action=version في المتصفح عشان تتأكد إن النشر بيشغّل الكود الجديد
  if (action === 'version') {
    return json_({
      version: APP_VERSION,
      configured: !!(secret_('ADMIN_PIN') && secret_('MANAGE_PIN')),
      time: new Date()
    });
  }

  if (action === 'adminLogin')  return json_(adminLogin_(e.parameter.pin));
  if (action === 'manageLogin') return json_(manageLogin_(e.parameter.pin));

  // الكتالوج مفتوح للكل (أسعار عامة، مفيش بيانات شخصية فيه)
  if (action === 'catalog') return json_(buildCatalogPayload_());

  const isAdmin = isValidAdminToken_(token);
  const isManage = isValidManageToken_(token);
  const me = userFromToken_(token);
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);

  // ═════════════════════════════════════════════════════════════
  //  🔒 lookup — كانت أخطر ثغرة في النظام كله
  // ═════════════════════════════════════════════════════════════
  //
  // النسخة القديمة مكانش عليها أي تحقق، وكانت بتطابق التليفون بـ:
  //     stored.endsWith(phone) || phone.endsWith(stored)
  // من غير أي حد أدنى لطول الرقم. يعني ?action=lookup&phone=1 كان بيرجّع كل
  // طلب رقمه بينتهي بـ 1 (~١٠٪ من الطلبات)، و**عشر نداءات بس كانت بتجيب كل
  // الطلبات في النظام** بأسماء الموزعين وأرقام تليفوناتهم وأصنافهم وكمياتهم
  // — من غير رقم سري ولا توكن ولا حاجة. ورابط الـ/exec نفسه مكتوب في
  // index.html اللي في مستودع عام.
  //
  // دلوقتي: لازم توكن. الموزّع يشوف طلباته هو بس، والأدمن يشوف الكل.
  if (action === 'lookup') {
    if (!isAdmin && !me) return denyAuth_();
    if (!sheet) return json_([]);
    const n = sheet.getLastRow() - 1;
    if (n < 1) return json_([]);

    let orders = sheet.getRange(2, 1, n, ORDERS_HEADERS.length).getValues()
      .filter(function (r) { return r[COL_ID - 1]; })
      .map(rowToOrder);

    if (!isAdmin) {
      // الموزّع: طلباته هو بس. المطابقة باسم المستخدم أولاً (دقيقة ١٠٠٪)،
      // والتليفون بمطابقة **كاملة** للطلبات القديمة اللي اتسجلت قبل ما
      // نضيف عمود اسم المستخدم.
      const info = userInfo_(me);
      const myPhone = info ? info.phone : '';
      orders = orders.filter(function (o) {
        if (o.username) return o.username.trim().toLowerCase() === me.trim().toLowerCase();
        return !!myPhone && normalizePhone(o.distPhone) === myPhone;
      });
    }

    if (e.parameter.ids) {
      const idSet = String(e.parameter.ids).split(',').map(function (x) { return x.trim().toLowerCase(); });
      orders = orders.filter(function (o) { return idSet.indexOf(o.id.toLowerCase()) !== -1; });
    } else if (e.parameter.phone) {
      // للأدمن بس — بحث برقم كامل، ومفيش endsWith خالص
      const phone = normalizePhone(e.parameter.phone);
      if (phone.length < 8) return json_([]);
      orders = orders.filter(function (o) { return normalizePhone(o.distPhone) === phone; });
    }

    orders.sort(function (a, b) { return b.ts - a.ts; });
    return json_(orders);
  }

  if (action === 'distributors') {
    if (!isAdmin) return denyAdmin_();
    return json_(listDistributors_());
  }

  // إشعار الأدمن: عدد الطلبات وآخر طلب بس (خفيف، للـ polling المتكرر)
  if (action === 'ordersMeta') {
    if (!isAdmin) return denyAdmin_();
    const n = sheet ? sheet.getLastRow() - 1 : 0;
    if (n < 1) return json_({ count: 0, last: null });
    const rows = sheet.getRange(2, 1, n, ORDERS_HEADERS.length).getValues();
    const seen = {};
    let count = 0, lastRow = null;
    for (let i = 0; i < rows.length; i++) {
      const id = String(rows[i][COL_ID - 1] || '');
      if (id && seen[id]) continue;
      if (id) seen[id] = true;
      count++;
      lastRow = rows[i];
    }
    return json_({
      count: count,
      last: lastRow ? {
        id: String(lastRow[COL_ID - 1] || ''),
        orderNo: String(lastRow[COL_ORDERNO - 1] || ''),
        distName: String(lastRow[COL_NAME - 1] || '')
      } : null
    });
  }

  // ---------- قوايم الموافقات ----------
  if (action === 'passwordRequests') {
    if (!isAdmin) return denyAdmin_();
    return json_(listPwRequests_());
  }
  if (action === 'managePasswordRequests') {
    if (!isManage) return denyManage_();
    return json_(listPwRequests_());
  }
  if (action === 'manageRegRequests') {
    if (!isManage) return denyManage_();
    return json_(listRegRequests_());
  }
  if (action === 'manageExportCatalog') {
    if (!isManage) return denyManage_();
    return json_(exportCatalogRows_());
  }

  // ⛔ العمليات اللي بتغيّر بيانات بقت في doPost — مابقتش تشتغل من رابط
  const MUTATIONS = ['updateStatus', 'delete', 'deleteDelivered', 'approvePasswordReset', 'rejectPasswordReset',
                     'manageApprovePasswordReset', 'manageRejectPasswordReset',
                     'manageApproveReg', 'manageRejectReg', 'login'];
  if (MUTATIONS.indexOf(action) !== -1) {
    return json_({ ok: false, error: 'use_post', message: 'العملية دي بقت POST — حدّث التطبيق.' });
  }

  // ---------- الافتراضي: كل الطلبات (لوحة المتابعة الإدارية) ----------
  if (!isAdmin) return denyAdmin_();
  lazyPurgeDone_();   // حذف المنفَّذ اللي عدّت ساعة على تنفيذه (شبكة أمان بجانب الـ trigger)
  if (!sheet) return json_([]);
  const n = sheet.getLastRow() - 1;
  if (n < 1) return json_([]);
  return json_(
    sheet.getRange(2, 1, n, ORDERS_HEADERS.length).getValues()
      .filter(function (r) { return r[COL_ID - 1]; })
      .map(rowToOrder)
      .reverse()
  );
}
// Display grouping only. No catalog/order/stock cells are written.
const ACC_DISPLAY_SHEET_ = 'مجموعات عرض الإكسسوارات';
const ACC_DISPLAY_KEYS_ = ['esp','hinges','handles','ends','locks','sealants','mesh','plastics','rest'];
function accDisplayReadText_(value){try{const x=JSON.parse(String(value));return typeof x==='string'?x:'';}catch(e){return '';}}
function readAccDisplayGroups_(){
  const sheet=SpreadsheetApp.getActiveSpreadsheet().getSheetByName(ACC_DISPLAY_SHEET_);
  if(!sheet || sheet.getLastRow()<2) return [];
  const byKey={},allowed=ACC_DISPLAY_KEYS_.concat(readAccCustomGroups_().map(g=>g.key));
  sheet.getRange(2,1,sheet.getLastRow()-1,4).getValues().forEach(r=>{
    const main=accDisplayReadText_(r[0]), product=accDisplayReadText_(r[1]), group=String(r[2]||'').trim();
    if(main && product && allowed.indexOf(group)>=0) byKey[JSON.stringify([main,product])]={main,product,group};
  });
  return Object.keys(byKey).map(k=>byKey[k]);
}
function setAccDisplayGroup_(data){
  const main=typeof data.main==='string'?data.main.trim():'';
  const product=typeof data.product==='string'?data.product.trim():'';
  const group=typeof data.group==='string'?data.group:'';
  const expected=typeof data.expectedGroup==='string'?data.expectedGroup:null;
  if(!main || !product || product.length>500 || (group && !validAccDisplayKey_(group)) || expected===null) return {ok:false,code:'BAD_GROUP'};
  if(!(main.indexOf('اكسسوارات')>=0 || main==='شاتر' || main==='ابواب WPC')) return {ok:false,code:'BAD_SECTOR'};
  const lock=LockService.getScriptLock();
  if(!lock.tryLock(5000)) return {ok:false,code:'GROUP_BUSY'};
  try{
    const ss=SpreadsheetApp.getActiveSpreadsheet(), cat=ss.getSheetByName(CATALOG_SHEET_NAME);
    if(!cat || cat.getLastRow()<2) return {ok:false,code:'PRODUCT_NOT_FOUND'};
    const found=cat.getRange(2,1,cat.getLastRow()-1,5).getValues().some(r=>String(r[1]||'').trim()===main && String(r[4]||r[0]||'').trim()===product);
    if(!found) return {ok:false,code:'PRODUCT_NOT_FOUND'};
    let sheet=ss.getSheetByName(ACC_DISPLAY_SHEET_), row=0, current='';
    if(sheet && sheet.getLastRow()>1){
      sheet.getRange(2,1,sheet.getLastRow()-1,4).getValues().forEach((r,i)=>{
        if(accDisplayReadText_(r[0])===main && accDisplayReadText_(r[1])===product){row=i+2;current=String(r[2]||'').trim();}
      });
    }
    if(current!==expected && current!==group) return {ok:false,code:'GROUP_CONFLICT',currentGroup:current};
    if(!sheet){sheet=ss.insertSheet(ACC_DISPLAY_SHEET_);sheet.getRange(1,1,1,4).setValues([['main_json','product_json','display_group','updated_at']]);}
    // JSON string cells start with a quote, not a spreadsheet formula prefix.
    const cells=sheet.getRange(row || sheet.getLastRow()+1,1,1,4);
    cells.setNumberFormat('@');
    cells.setValues([[JSON.stringify(main),JSON.stringify(product),group,new Date().toISOString()]]);
    SpreadsheetApp.flush();
    return {ok:true,main,product,group};
  }finally{lock.releaseLock();}
}


// Custom display-group definitions are separate from product assignments.
const ACC_CUSTOM_SHEET_ = 'تعريف مجموعات الإكسسوارات';
const ACC_BUILTIN_LABELS_ = ['السبلونات','المفصلات','المقابض','نهاية بوكلير','كوالين وتسكيكات','سيليكون وفوم','سلك وستاير','بلاستيكات','باقي الأصناف'];
function accLabelKey_(s){return String(s||'').trim().replace(/[أإآ]/g,'ا').replace(/ة/g,'ه').replace(/ى/g,'ي').replace(/[ً-ْٰـ]/g,'').replace(/\s+/g,' ').toLowerCase();}
function readAccCustomGroups_(){
  const sheet=SpreadsheetApp.getActiveSpreadsheet().getSheetByName(ACC_CUSTOM_SHEET_);
  if(!sheet || sheet.getLastRow()<2)return [];
  const seen={};const out=[];
  sheet.getRange(2,1,sheet.getLastRow()-1,3).getValues().forEach(r=>{
    const key=String(r[0]||''),label=accDisplayReadText_(r[1]);
    if(/^custom_[a-f0-9-]{36}$/.test(key) && label && label.length<=60 && !seen[key]){seen[key]=true;out.push({key,label,sub:''});}
  });return out;
}
function validAccDisplayKey_(key){return ACC_DISPLAY_KEYS_.indexOf(key)>=0 || readAccCustomGroups_().some(g=>g.key===key);}
function createAccCustomGroup_(data){
  const label=typeof data.label==='string'?data.label.trim().replace(/\s+/g,' '):'';
  if(!label || label.length>60 || /[\u0000-\u001f\u007f<>]/.test(label))return {ok:false,code:'BAD_LABEL'};
  const lock=LockService.getScriptLock();if(!lock.tryLock(5000))return {ok:false,code:'GROUP_BUSY'};
  try{
    const list=readAccCustomGroups_(),norm=accLabelKey_(label);
    if(ACC_BUILTIN_LABELS_.some(s=>accLabelKey_(s)===norm))return {ok:false,code:'DUPLICATE_GROUP'};
    const existing=list.find(g=>accLabelKey_(g.label)===norm);
    if(existing)return {ok:true,group:existing,customGroups:list,existing:true};
    if(list.length>=40)return {ok:false,code:'GROUP_LIMIT'};
    const ss=SpreadsheetApp.getActiveSpreadsheet();let sheet=ss.getSheetByName(ACC_CUSTOM_SHEET_);
    if(!sheet){sheet=ss.insertSheet(ACC_CUSTOM_SHEET_);sheet.getRange(1,1,1,3).setValues([['key','label_json','created_at']]);}
    const group={key:'custom_'+Utilities.getUuid().toLowerCase(),label,sub:''};
    sheet.getRange(sheet.getLastRow()+1,1,1,3).setNumberFormat('@').setValues([[group.key,JSON.stringify(label),new Date().toISOString()]]);
    SpreadsheetApp.flush();return {ok:true,group,customGroups:list.concat([group]),existing:false};
  }finally{lock.releaseLock();}
}
